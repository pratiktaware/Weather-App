const apiKey = "3fd0930ffed39237e43273704cbfc6a8"; 

window.onload = () => {
  renderHistory();
  if ("geolocation" in navigator) {
    navigator.geolocation.getCurrentPosition(async (position) => {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;
      await getWeatherByCoords(lat, lon);
    });
  }
};

async function getWeather() {
  const city = document.getElementById("cityInput").value;
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error("City not found");
    const data = await response.json();
    displayWeather(data);
    saveToHistory(city);
  } catch (error) {
    document.getElementById("weatherResult").innerHTML = `<p>${error.message}</p>`;
  }
}

async function getWeatherByCoords(lat, lon) {
  const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
  try {
    const response = await fetch(url);
    const data = await response.json();
    displayWeather(data);
    saveToHistory(data.name);
  } catch (error) {
    document.getElementById("weatherResult").innerHTML = `<p>${error.message}</p>`;
  }
}

function displayWeather(data) {
  const weather = `
    <h2>Weather in ${data.name}</h2>
    <p>Temperature: ${data.main.temp}°C</p>
    <p>Weather: ${data.weather[0].description}</p>
    <p>Humidity: ${data.main.humidity}%</p>
    <p>Wind Speed: ${data.wind.speed} m/s</p>
  `;
  document.getElementById("weatherResult").innerHTML = weather;
  getForecast(data.name);
}

async function getForecast(city) {
  const url = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    const forecastHTML = data.list
      .filter((_, index) => index % 8 === 0) // Show 1 forecast per day
      .map(item => `
        <div class="forecast-item">
          <p><strong>${new Date(item.dt_txt).toLocaleDateString()}</strong></p>
          <p>Temp: ${item.main.temp}°C</p>
          <p>${item.weather[0].main}</p>
        </div>
      `).join("");

    document.getElementById("forecastContainer").innerHTML = `
      <h3>5-Day Forecast</h3>
      <div class="forecast">${forecastHTML}</div>
    `;
  } catch (error) {
    document.getElementById("forecastContainer").innerHTML = `<p>Could not load forecast</p>`;
  }
}

function saveToHistory(city) {
  let history = JSON.parse(localStorage.getItem("history")) || [];
  if (!history.includes(city)) {
    history.unshift(city);
    if (history.length > 5) history.pop(); // keep only last 5 searches
    localStorage.setItem("history", JSON.stringify(history));
    renderHistory();
  }
}

function renderHistory() {
  const history = JSON.parse(localStorage.getItem("history")) || [];
  const list = document.getElementById("historyList");
  list.innerHTML = "";

  history.forEach(city => {
    const li = document.createElement("li");
    li.textContent = city;
    li.onclick = () => {
      document.getElementById("cityInput").value = city;
      getWeather();
    };
    list.appendChild(li);
  });
}
